class Password {
  static bool show = false;
  static showPassword() {}
}
