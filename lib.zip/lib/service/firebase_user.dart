import 'package:firebase_auth/firebase_auth.dart';

class AuthUser {
  static final FirebaseAuth authUser = FirebaseAuth.instance;
}
