import 'package:cloud_firestore/cloud_firestore.dart';

class Firestore {
  static final FirebaseFirestore firestore = FirebaseFirestore.instance;
}
