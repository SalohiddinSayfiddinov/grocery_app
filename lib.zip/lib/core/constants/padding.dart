import 'package:zakaz/size_config/size_config.dart';

class Constants {
  static var kPadding = getHeight(15.0);
}
